class AppConfig {
  static const String appName = 'CricGo';
  static const String developer = 'Shashendra Nirvan';
  static const String tagline = 'Every match. Everywhere.';

  // Provided at build time: flutter build apk --dart-define=CRICKET_API_KEY=xxxx
  static const String apiKey = String.fromEnvironment('CRICKET_API_KEY');
  static const String apiBase = 'https://api.cricapi.com/v1';

  static bool get hasApiKey => apiKey.isNotEmpty;
}
