import 'dart:async';

import 'package:flutter/foundation.dart';

import '../config/app_config.dart';
import '../data/sample_matches.dart';
import '../models/cricket_match.dart';
import 'cricket_api.dart';

enum LoadState { loading, ready, error }

class MatchRepository extends ChangeNotifier {
  final CricketApi _api = CricketApi();
  Timer? _timer;

  LoadState state = LoadState.loading;
  List<CricketMatch> matches = [];
  String? error;
  bool demoMode = false;
  DateTime? lastUpdated;

  Future<void> load() async {
    if (!AppConfig.hasApiKey) {
      matches = sampleMatches();
      demoMode = true;
      error = null;
      state = LoadState.ready;
      lastUpdated = DateTime.now();
      notifyListeners();
      return;
    }

    if (matches.isEmpty) {
      state = LoadState.loading;
      notifyListeners();
    }

    try {
      matches = await _api.fetchCurrentMatches();
      demoMode = false;
      error = null;
      state = LoadState.ready;
      lastUpdated = DateTime.now();
    } catch (e) {
      error = e is ApiException ? e.message : 'Something went wrong.';
      if (matches.isEmpty) state = LoadState.error;
    }
    notifyListeners();
  }

  List<CricketMatch> byStatus(MatchStatus status) {
    final list = matches.where((m) => m.status == status).toList();
    list.sort((a, b) => status == MatchStatus.upcoming
        ? a.startTime.compareTo(b.startTime)
        : b.startTime.compareTo(a.startTime));
    return list;
  }

  /// Refreshes every 3 minutes while the app is open (keeps API usage low).
  void startAutoRefresh() {
    if (!AppConfig.hasApiKey) return;
    _timer?.cancel();
    _timer = Timer.periodic(const Duration(minutes: 3), (_) => load());
  }

  void stopAutoRefresh() {
    _timer?.cancel();
    _timer = null;
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }
}
