import 'dart:convert';

import 'package:http/http.dart' as http;

import '../config/app_config.dart';
import '../models/cricket_match.dart';

class ApiException implements Exception {
  final String message;
  const ApiException(this.message);

  @override
  String toString() => message;
}

class CricketApi {
  Future<List<CricketMatch>> fetchCurrentMatches() async {
    final uri = Uri.parse(
      '${AppConfig.apiBase}/currentMatches?apikey=${AppConfig.apiKey}&offset=0',
    );

    final http.Response res;
    try {
      res = await http.get(uri).timeout(const Duration(seconds: 15));
    } catch (_) {
      throw const ApiException(
          'Could not reach the server. Check your internet connection.');
    }

    if (res.statusCode != 200) {
      throw ApiException('Server error (${res.statusCode}). Try again later.');
    }

    final dynamic body = jsonDecode(res.body);
    if (body is! Map<String, dynamic>) {
      throw const ApiException('Unexpected response from the server.');
    }
    if (body['status'] != 'success') {
      throw ApiException((body['reason'] ?? 'The data service refused the request.')
          .toString());
    }

    final data = (body['data'] as List?) ?? <dynamic>[];
    return data
        .whereType<Map<String, dynamic>>()
        .map(CricketMatch.fromApi)
        .toList();
  }
}
