import 'package:flutter/material.dart';

import '../services/match_repository.dart';
import '../theme/theme_controller.dart';
import 'matches_screen.dart';
import 'settings_screen.dart';
import 'watch_screen.dart';

class MainShell extends StatefulWidget {
  final MatchRepository repo;
  final ThemeController theme;

  const MainShell({super.key, required this.repo, required this.theme});

  @override
  State<MainShell> createState() => _MainShellState();
}

class _MainShellState extends State<MainShell> {
  int _index = 0;

  @override
  void initState() {
    super.initState();
    widget.repo.startAutoRefresh();
  }

  @override
  void dispose() {
    widget.repo.stopAutoRefresh();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: IndexedStack(
        index: _index,
        children: [
          MatchesScreen(repo: widget.repo, theme: widget.theme),
          const WatchScreen(),
          SettingsScreen(repo: widget.repo, theme: widget.theme),
        ],
      ),
      bottomNavigationBar: NavigationBar(
        selectedIndex: _index,
        onDestinationSelected: (i) => setState(() => _index = i),
        destinations: const [
          NavigationDestination(
            icon: Icon(Icons.sports_cricket_outlined),
            selectedIcon: Icon(Icons.sports_cricket),
            label: 'Matches',
          ),
          NavigationDestination(
            icon: Icon(Icons.live_tv_outlined),
            selectedIcon: Icon(Icons.live_tv),
            label: 'Watch',
          ),
          NavigationDestination(
            icon: Icon(Icons.settings_outlined),
            selectedIcon: Icon(Icons.settings),
            label: 'Settings',
          ),
        ],
      ),
    );
  }
}
