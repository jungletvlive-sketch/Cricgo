import 'package:flutter/material.dart';

import '../config/app_config.dart';
import '../services/match_repository.dart';
import '../theme/app_theme.dart';
import '../theme/theme_controller.dart';
import '../widgets/cricgo_logo.dart';

class SettingsScreen extends StatelessWidget {
  final MatchRepository repo;
  final ThemeController theme;

  const SettingsScreen({super.key, required this.repo, required this.theme});

  @override
  Widget build(BuildContext context) {
    final muted = AppColors.muted(context);

    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'Settings',
          style: TextStyle(fontWeight: FontWeight.w800),
        ),
      ),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(16, 8, 16, 32),
        children: [
          _Card(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  'Appearance',
                  style: TextStyle(fontSize: 15, fontWeight: FontWeight.w700),
                ),
                const SizedBox(height: 12),
                ListenableBuilder(
                  listenable: theme,
                  builder: (context, _) => SizedBox(
                    width: double.infinity,
                    child: SegmentedButton<ThemeMode>(
                      showSelectedIcon: false,
                      segments: const [
                        ButtonSegment(
                          value: ThemeMode.light,
                          icon: Icon(Icons.light_mode_outlined),
                          label: Text('Light'),
                        ),
                        ButtonSegment(
                          value: ThemeMode.dark,
                          icon: Icon(Icons.dark_mode_outlined),
                          label: Text('Dark'),
                        ),
                        ButtonSegment(
                          value: ThemeMode.system,
                          icon: Icon(Icons.phone_android),
                          label: Text('Auto'),
                        ),
                      ],
                      selected: {theme.mode},
                      onSelectionChanged: (s) => theme.set(s.first),
                    ),
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 12),
          _Card(
            child: ListenableBuilder(
              listenable: repo,
              builder: (context, _) => Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    'Data',
                    style: TextStyle(fontSize: 15, fontWeight: FontWeight.w700),
                  ),
                  const SizedBox(height: 10),
                  Text(
                    repo.demoMode
                        ? 'Mode: Demo data (no API key in this build)'
                        : 'Mode: Live data',
                    style: TextStyle(color: muted, fontSize: 13),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    'Source: CricketData.org',
                    style: TextStyle(color: muted, fontSize: 13),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    'Auto refresh: every 3 minutes',
                    style: TextStyle(color: muted, fontSize: 13),
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 12),
          _Card(
            child: Column(
              children: [
                const CricGoLogo(size: 64, glow: true),
                const SizedBox(height: 14),
                const Text(
                  AppConfig.appName,
                  style: TextStyle(fontSize: 20, fontWeight: FontWeight.w800),
                ),
                const SizedBox(height: 2),
                Text(
                  AppConfig.tagline,
                  style: TextStyle(color: muted, fontSize: 12),
                ),
                const SizedBox(height: 16),
                Text('Developed by', style: TextStyle(color: muted, fontSize: 11)),
                const SizedBox(height: 2),
                const Text(
                  AppConfig.developer,
                  style: TextStyle(fontSize: 15, fontWeight: FontWeight.w700),
                ),
                const SizedBox(height: 16),
                Text(
                  'CricGo does not host or stream any video. Watch buttons open '
                  'official third-party services.',
                  textAlign: TextAlign.center,
                  style: TextStyle(color: muted, fontSize: 11),
                ),
                const SizedBox(height: 8),
                Text('Version 1.0.0', style: TextStyle(color: muted, fontSize: 11)),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _Card extends StatelessWidget {
  final Widget child;
  const _Card({required this.child});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: AppColors.card(context),
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: AppColors.border(context)),
      ),
      child: child,
    );
  }
}
