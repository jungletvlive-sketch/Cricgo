import 'package:flutter/material.dart';

import '../data/watch_sites.dart';
import '../theme/app_theme.dart';
import '../widgets/category_section.dart';

class WatchScreen extends StatelessWidget {
  const WatchScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'Watch Live',
          style: TextStyle(fontWeight: FontWeight.w800),
        ),
      ),
      body: ListView(
        padding: const EdgeInsets.only(bottom: 32),
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 0, 16, 0),
            child: Text(
              'Find where to watch cricket. Tap a service to open it.',
              style: TextStyle(color: AppColors.muted(context), fontSize: 13),
            ),
          ),
          ...watchCategories.map((c) => CategorySection(category: c)),
          Padding(
            padding: const EdgeInsets.fromLTRB(20, 24, 20, 0),
            child: Text(
              'CricGo does not host or stream any video. These buttons open '
              'official third-party services. Availability depends on your country.',
              style: TextStyle(fontSize: 11, color: AppColors.muted(context)),
            ),
          ),
        ],
      ),
    );
  }
}
