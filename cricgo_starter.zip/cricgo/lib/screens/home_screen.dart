import 'package:flutter/material.dart';

import '../data/sample_matches.dart';
import '../models/cricket_match.dart';
import '../widgets/match_card.dart';
import 'watch_options_screen.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final matches = sampleMatches();
    final live = matches.where((m) => m.status == MatchStatus.live).toList();
    final upcoming =
        matches.where((m) => m.status == MatchStatus.upcoming).toList();

    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'CricGo',
          style: TextStyle(fontWeight: FontWeight.bold),
        ),
        centerTitle: false,
      ),
      body: ListView(
        padding: const EdgeInsets.only(bottom: 24),
        children: [
          if (live.isNotEmpty) ...[
            const _SectionTitle('Live Now'),
            ...live.map((m) => _card(context, m)),
          ],
          const _SectionTitle('Upcoming'),
          ...upcoming.map((m) => _card(context, m)),
        ],
      ),
    );
  }

  Widget _card(BuildContext context, CricketMatch m) {
    return MatchCard(
      match: m,
      onTap: () => Navigator.of(context).push(
        MaterialPageRoute(builder: (_) => WatchOptionsScreen(match: m)),
      ),
    );
  }
}

class _SectionTitle extends StatelessWidget {
  final String text;
  const _SectionTitle(this.text);

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 20, 16, 4),
      child: Text(
        text,
        style: Theme.of(context)
            .textTheme
            .titleLarge
            ?.copyWith(fontWeight: FontWeight.bold),
      ),
    );
  }
}
