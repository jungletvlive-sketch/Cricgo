import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:url_launcher/url_launcher.dart';

import '../models/cricket_match.dart';
import '../theme/app_theme.dart';

class WatchOptionsScreen extends StatelessWidget {
  final CricketMatch match;

  const WatchOptionsScreen({super.key, required this.match});

  Future<void> _open(BuildContext context, String url) async {
    final ok = await launchUrl(
      Uri.parse(url),
      mode: LaunchMode.externalApplication,
    );
    if (!ok && context.mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Could not open the link')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    final time = DateFormat('EEEE, d MMM yyyy • h:mm a')
        .format(match.startTime.toLocal());

    return Scaffold(
      appBar: AppBar(title: const Text('Match Details')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Text(
            '${match.teamA}  vs  ${match.teamB}',
            style: Theme.of(context)
                .textTheme
                .headlineSmall
                ?.copyWith(fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 6),
          Text('${match.series} • ${match.format}'),
          const SizedBox(height: 12),
          Row(children: [
            const Icon(Icons.schedule, size: 18),
            const SizedBox(width: 8),
            Expanded(child: Text(time)),
          ]),
          const SizedBox(height: 6),
          Row(children: [
            const Icon(Icons.location_on_outlined, size: 18),
            const SizedBox(width: 8),
            Expanded(child: Text(match.venue)),
          ]),
          const SizedBox(height: 28),
          Text(
            'Where to watch',
            style: Theme.of(context)
                .textTheme
                .titleLarge
                ?.copyWith(fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 12),
          if (match.broadcasters.isEmpty)
            const Text('No broadcast info available yet.')
          else
            ...match.broadcasters.map(
              (b) => Padding(
                padding: const EdgeInsets.only(bottom: 10),
                child: FilledButton.icon(
                  style: FilledButton.styleFrom(
                    backgroundColor: AppColors.accent,
                    foregroundColor: Colors.white,
                    padding: const EdgeInsets.symmetric(
                        horizontal: 16, vertical: 16),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(14),
                    ),
                  ),
                  onPressed: () => _open(context, b.url),
                  icon: const Icon(Icons.play_arrow_rounded),
                  label: Align(
                    alignment: Alignment.centerLeft,
                    child: Text('${b.name}  •  ${b.country}'),
                  ),
                ),
              ),
            ),
        ],
      ),
    );
  }
}
