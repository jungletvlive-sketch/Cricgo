import 'package:flutter/material.dart';

import '../data/watch_sites.dart';
import '../models/cricket_match.dart';
import '../theme/app_theme.dart';
import '../utils/helpers.dart';
import '../widgets/category_section.dart';
import '../widgets/team_badge.dart';

class MatchDetailScreen extends StatelessWidget {
  final CricketMatch match;

  const MatchDetailScreen({super.key, required this.match});

  @override
  Widget build(BuildContext context) {
    final muted = AppColors.muted(context);
    final finished = match.status == MatchStatus.completed;
    // Live/upcoming: streaming + scores. Finished: scores and highlights.
    final categories = finished
        ? [watchCategories[1], watchCategories[2]]
        : [watchCategories[0], watchCategories[1]];

    return Scaffold(
      appBar: AppBar(title: const Text('Match Details')),
      body: ListView(
        padding: const EdgeInsets.only(bottom: 32),
        children: [
          Container(
            margin: const EdgeInsets.fromLTRB(16, 8, 16, 0),
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(
              color: AppColors.card(context),
              borderRadius: BorderRadius.circular(20),
              border: Border.all(color: AppColors.border(context)),
            ),
            child: Column(
              children: [
                Text(
                  [match.format, match.title]
                      .where((e) => e.isNotEmpty)
                      .join(' • '),
                  textAlign: TextAlign.center,
                  style: TextStyle(color: muted, fontSize: 12),
                ),
                const SizedBox(height: 18),
                Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Expanded(
                      child: _TeamColumn(team: match.teamA, score: match.scoreA),
                    ),
                    Padding(
                      padding: const EdgeInsets.only(top: 14),
                      child: Text('VS',
                          style: TextStyle(
                              color: muted,
                              fontWeight: FontWeight.w700,
                              fontSize: 12)),
                    ),
                    Expanded(
                      child: _TeamColumn(team: match.teamB, score: match.scoreB),
                    ),
                  ],
                ),
                if (match.statusText.isNotEmpty) ...[
                  const SizedBox(height: 18),
                  Text(
                    match.statusText,
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      color: match.status == MatchStatus.live
                          ? AppColors.accent
                          : muted,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ],
                const SizedBox(height: 14),
                Divider(height: 1, color: AppColors.border(context)),
                const SizedBox(height: 14),
                _InfoRow(Icons.schedule, formatMatchTime(match.startTime)),
                if (match.venue.isNotEmpty) ...[
                  const SizedBox(height: 8),
                  _InfoRow(Icons.location_on_outlined, match.venue),
                ],
              ],
            ),
          ),
          ...categories.map((c) => CategorySection(category: c)),
          Padding(
            padding: const EdgeInsets.fromLTRB(20, 20, 20, 0),
            child: Text(
              'CricGo does not host or stream any video. These buttons open '
              'official third-party services. Availability depends on your country.',
              style: TextStyle(fontSize: 11, color: muted),
            ),
          ),
        ],
      ),
    );
  }
}

class _TeamColumn extends StatelessWidget {
  final TeamInfo team;
  final String score;

  const _TeamColumn({required this.team, required this.score});

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        TeamBadge(team: team, size: 58),
        const SizedBox(height: 10),
        Text(
          team.name,
          textAlign: TextAlign.center,
          maxLines: 2,
          overflow: TextOverflow.ellipsis,
          style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w600),
        ),
        if (score.isNotEmpty) ...[
          const SizedBox(height: 6),
          Text(
            score,
            textAlign: TextAlign.center,
            style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w800),
          ),
        ],
      ],
    );
  }
}

class _InfoRow extends StatelessWidget {
  final IconData icon;
  final String text;

  const _InfoRow(this.icon, this.text);

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Icon(icon, size: 17, color: AppColors.muted(context)),
        const SizedBox(width: 10),
        Expanded(child: Text(text, style: const TextStyle(fontSize: 13))),
      ],
    );
  }
}
