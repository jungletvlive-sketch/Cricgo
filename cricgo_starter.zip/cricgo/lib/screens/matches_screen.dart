import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

import '../models/cricket_match.dart';
import '../services/match_repository.dart';
import '../theme/app_theme.dart';
import '../theme/theme_controller.dart';
import '../widgets/cricgo_logo.dart';
import '../widgets/match_card.dart';
import '../widgets/state_views.dart';
import 'match_detail_screen.dart';

class MatchesScreen extends StatelessWidget {
  final MatchRepository repo;
  final ThemeController theme;

  const MatchesScreen({super.key, required this.repo, required this.theme});

  @override
  Widget build(BuildContext context) {
    final dark = AppColors.isDark(context);

    return DefaultTabController(
      length: 3,
      child: Scaffold(
        appBar: AppBar(
          title: const Row(
            children: [
              CricGoLogo(size: 30),
              SizedBox(width: 10),
              Text(
                'CricGo',
                style: TextStyle(fontWeight: FontWeight.w800, letterSpacing: 0.5),
              ),
            ],
          ),
          actions: [
            IconButton(
              tooltip: dark ? 'Switch to light mode' : 'Switch to dark mode',
              icon: Icon(dark ? Icons.light_mode_outlined : Icons.dark_mode_outlined),
              onPressed: () => theme.toggle(Theme.of(context).brightness),
            ),
            const SizedBox(width: 4),
          ],
          bottom: const TabBar(
            indicatorColor: AppColors.accent,
            indicatorSize: TabBarIndicatorSize.label,
            dividerColor: Colors.transparent,
            tabs: [
              Tab(text: 'Live'),
              Tab(text: 'Upcoming'),
              Tab(text: 'Results'),
            ],
          ),
        ),
        body: ListenableBuilder(
          listenable: repo,
          builder: (context, _) {
            switch (repo.state) {
              case LoadState.loading:
                return const SkeletonList();
              case LoadState.error:
                return ErrorView(
                  message: repo.error ?? 'Something went wrong.',
                  onRetry: repo.load,
                );
              case LoadState.ready:
                return Column(
                  children: [
                    if (repo.demoMode) const _DemoBanner(),
                    Expanded(
                      child: TabBarView(
                        children: [
                          _MatchList(repo: repo, status: MatchStatus.live),
                          _MatchList(repo: repo, status: MatchStatus.upcoming),
                          _MatchList(repo: repo, status: MatchStatus.completed),
                        ],
                      ),
                    ),
                  ],
                );
            }
          },
        ),
      ),
    );
  }
}

class _MatchList extends StatelessWidget {
  final MatchRepository repo;
  final MatchStatus status;

  const _MatchList({required this.repo, required this.status});

  String get _emptyMessage {
    switch (status) {
      case MatchStatus.live:
        return 'No live matches right now.\nPull down to refresh.';
      case MatchStatus.upcoming:
        return 'No upcoming matches found.';
      case MatchStatus.completed:
        return 'No recent results yet.';
    }
  }

  @override
  Widget build(BuildContext context) {
    final items = repo.byStatus(status);

    return RefreshIndicator(
      color: AppColors.accent,
      onRefresh: repo.load,
      child: items.isEmpty
          ? ListView(
              physics: const AlwaysScrollableScrollPhysics(),
              children: [
                const SizedBox(height: 90),
                EmptyState(
                  icon: Icons.sports_cricket_outlined,
                  message: _emptyMessage,
                ),
              ],
            )
          : ListView.builder(
              physics: const AlwaysScrollableScrollPhysics(),
              padding: const EdgeInsets.only(top: 8, bottom: 24),
              itemCount: items.length + 1,
              itemBuilder: (context, i) {
                if (i == items.length) return _UpdatedFooter(repo: repo);
                final m = items[i];
                return MatchCard(
                  match: m,
                  onTap: () => Navigator.of(context).push(
                    MaterialPageRoute(
                      builder: (_) => MatchDetailScreen(match: m),
                    ),
                  ),
                );
              },
            ),
    );
  }
}

class _UpdatedFooter extends StatelessWidget {
  final MatchRepository repo;
  const _UpdatedFooter({required this.repo});

  @override
  Widget build(BuildContext context) {
    final t = repo.lastUpdated;
    final text = t == null
        ? 'Pull down to refresh'
        : 'Updated ${DateFormat('h:mm a').format(t)} • Pull down to refresh';
    return Padding(
      padding: const EdgeInsets.only(top: 14),
      child: Center(
        child: Text(
          text,
          style: TextStyle(fontSize: 11, color: AppColors.muted(context)),
        ),
      ),
    );
  }
}

class _DemoBanner extends StatelessWidget {
  const _DemoBanner();

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      margin: const EdgeInsets.fromLTRB(16, 4, 16, 4),
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
      decoration: BoxDecoration(
        color: AppColors.accent.withValues(alpha: 0.14),
        borderRadius: BorderRadius.circular(12),
      ),
      child: const Row(
        children: [
          Icon(Icons.info_outline, size: 16, color: AppColors.accent),
          SizedBox(width: 8),
          Expanded(
            child: Text(
              'Demo data. Live scores need a data API key.',
              style: TextStyle(fontSize: 12, color: AppColors.accent),
            ),
          ),
        ],
      ),
    );
  }
}
