enum MatchStatus { live, upcoming, completed }

class Broadcaster {
  final String name;
  final String country;
  final String url;

  const Broadcaster({
    required this.name,
    required this.country,
    required this.url,
  });
}

class CricketMatch {
  final String id;
  final String series;
  final String format; // T20, ODI, Test
  final String teamA;
  final String teamB;
  final DateTime startTime;
  final String venue;
  final MatchStatus status;
  final String? scoreSummary;
  final List<Broadcaster> broadcasters;

  const CricketMatch({
    required this.id,
    required this.series,
    required this.format,
    required this.teamA,
    required this.teamB,
    required this.startTime,
    required this.venue,
    required this.status,
    this.scoreSummary,
    this.broadcasters = const [],
  });
}
