enum MatchStatus { live, upcoming, completed }

class TeamInfo {
  final String name;
  final String shortName;
  final String? imageUrl;

  const TeamInfo({
    required this.name,
    required this.shortName,
    this.imageUrl,
  });
}

class CricketMatch {
  final String id;
  final String title;
  final String format;
  final TeamInfo teamA;
  final TeamInfo teamB;
  final String scoreA;
  final String scoreB;
  final DateTime startTime;
  final String venue;
  final MatchStatus status;
  final String statusText;

  const CricketMatch({
    required this.id,
    required this.title,
    required this.format,
    required this.teamA,
    required this.teamB,
    this.scoreA = '',
    this.scoreB = '',
    required this.startTime,
    required this.venue,
    required this.status,
    this.statusText = '',
  });

  /// Builds a match from one item of the CricketData `currentMatches` response.
  /// Every field is read defensively because the API may omit some of them.
  factory CricketMatch.fromApi(Map<String, dynamic> j) {
    final teams = (j['teams'] as List?)?.map((e) => e.toString()).toList() ??
        <String>[];
    final infos = (j['teamInfo'] as List?)?.whereType<Map>().toList() ??
        <Map>[];

    TeamInfo buildTeam(int i) {
      final name = i < teams.length ? teams[i] : 'TBA';
      Map? info;
      for (final m in infos) {
        if (m['name']?.toString() == name) info = m;
      }
      final short = info?['shortname']?.toString();
      final img = info?['img']?.toString();
      return TeamInfo(
        name: name,
        shortName: (short != null && short.isNotEmpty) ? short : _short(name),
        imageUrl: (img != null && img.startsWith('http')) ? img : null,
      );
    }

    final teamA = buildTeam(0);
    final teamB = buildTeam(1);

    final scoreList = (j['score'] as List?)?.whereType<Map>().toList() ??
        <Map>[];
    String scoreFor(String teamName) {
      final parts = <String>[];
      for (final s in scoreList) {
        final inning = (s['inning'] ?? '').toString().toLowerCase();
        if (inning.contains(teamName.toLowerCase()) && s['r'] != null) {
          final w = s['w'] ?? 0;
          final o = s['o'] ?? '-';
          parts.add('${s['r']}/$w ($o)');
        }
      }
      return parts.join(' & ');
    }

    final rawName = (j['name'] ?? '').toString();
    final commaAt = rawName.lastIndexOf(',');
    final title = commaAt >= 0 ? rawName.substring(commaAt + 1).trim() : rawName;

    final statusText = (j['status'] ?? '').toString();
    final start = _parseTime(j['dateTimeGMT']);

    return CricketMatch(
      id: (j['id'] ?? rawName).toString(),
      title: title,
      format: (j['matchType'] ?? '').toString().toUpperCase(),
      teamA: teamA,
      teamB: teamB,
      scoreA: scoreFor(teamA.name),
      scoreB: scoreFor(teamB.name),
      startTime: start,
      venue: (j['venue'] ?? '').toString(),
      status: _classify(j, statusText, start),
      statusText: statusText,
    );
  }
}

String _short(String name) {
  final words = name.trim().split(RegExp(r'\s+'));
  if (words.length >= 2) {
    return words.map((w) => w.isEmpty ? '' : w[0]).join().toUpperCase();
  }
  return name.length >= 3
      ? name.substring(0, 3).toUpperCase()
      : name.toUpperCase();
}

DateTime _parseTime(dynamic v) {
  final s = v?.toString();
  if (s == null || s.isEmpty) return DateTime.now();
  final hasZone = s.endsWith('Z') || RegExp(r'[+-]\d\d:?\d\d$').hasMatch(s);
  return DateTime.tryParse(hasZone ? s : '${s}Z') ?? DateTime.now();
}

MatchStatus _classify(Map<String, dynamic> j, String statusText, DateTime start) {
  final text = statusText.toLowerCase();
  final finished = j['matchEnded'] == true ||
      text.contains('won') ||
      text.contains('draw') ||
      text.contains('tied') ||
      text.contains('no result') ||
      text.contains('abandon');
  if (finished) return MatchStatus.completed;
  if (j['matchStarted'] == true) return MatchStatus.live;
  if (j['matchStarted'] == false) return MatchStatus.upcoming;
  if (text.contains('not started') || start.isAfter(DateTime.now())) {
    return MatchStatus.upcoming;
  }
  return MatchStatus.live;
}
