import 'package:flutter/material.dart';

import 'config/app_config.dart';
import 'screens/main_shell.dart';
import 'screens/splash_screen.dart';
import 'services/match_repository.dart';
import 'theme/app_theme.dart';
import 'theme/theme_controller.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const CricGoApp());
}

class CricGoApp extends StatefulWidget {
  const CricGoApp({super.key});

  @override
  State<CricGoApp> createState() => _CricGoAppState();
}

class _CricGoAppState extends State<CricGoApp> {
  final ThemeController _theme = ThemeController();
  final MatchRepository _repo = MatchRepository();
  bool _ready = false;

  @override
  void initState() {
    super.initState();
    _boot();
  }

  Future<void> _boot() async {
    await Future.wait<void>([
      _theme.load(),
      Future<void>.delayed(const Duration(milliseconds: 2600)),
      _repo.load().timeout(const Duration(seconds: 7), onTimeout: () {}),
    ]);
    if (mounted) setState(() => _ready = true);
  }

  @override
  void dispose() {
    _theme.dispose();
    _repo.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: _theme,
      builder: (context, _) => MaterialApp(
        title: AppConfig.appName,
        debugShowCheckedModeBanner: false,
        theme: AppTheme.light(),
        darkTheme: AppTheme.dark(),
        themeMode: _theme.mode,
        home: AnimatedSwitcher(
          duration: const Duration(milliseconds: 500),
          child: _ready
              ? MainShell(
                  key: const ValueKey('shell'),
                  repo: _repo,
                  theme: _theme,
                )
              : const SplashScreen(key: ValueKey('splash')),
        ),
      ),
    );
  }
}
