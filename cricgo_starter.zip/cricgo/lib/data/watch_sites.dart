import 'package:flutter/material.dart';

class WatchSite {
  final String name;
  final String description;
  final String region;
  final String url;
  final IconData icon;

  const WatchSite({
    required this.name,
    required this.description,
    required this.region,
    required this.url,
    required this.icon,
  });
}

class WatchCategory {
  final String title;
  final String subtitle;
  final IconData icon;
  final List<WatchSite> sites;

  const WatchCategory({
    required this.title,
    required this.subtitle,
    required this.icon,
    required this.sites,
  });
}

// Official / licensed services only. Availability depends on the viewer's
// country. Edit this list any time to add or remove sites.
const List<WatchCategory> watchCategories = [
  WatchCategory(
    title: 'Live Streaming',
    subtitle: 'Official broadcasters (some need a subscription)',
    icon: Icons.live_tv,
    sites: [
      WatchSite(
        name: 'Willow',
        description: 'Live cricket streaming',
        region: 'USA & Canada',
        url: 'https://www.willow.tv',
        icon: Icons.play_circle_outline,
      ),
      WatchSite(
        name: 'Sony LIV',
        description: 'Live international cricket',
        region: 'India',
        url: 'https://www.sonyliv.com',
        icon: Icons.play_circle_outline,
      ),
      WatchSite(
        name: 'JioHotstar',
        description: 'Live cricket and league matches',
        region: 'India',
        url: 'https://www.jiohotstar.com',
        icon: Icons.play_circle_outline,
      ),
      WatchSite(
        name: 'Sky Sports Cricket',
        description: 'Tests, ODIs and T20s',
        region: 'UK & Ireland',
        url: 'https://www.skysports.com/cricket',
        icon: Icons.play_circle_outline,
      ),
      WatchSite(
        name: 'Kayo Sports',
        description: 'Live cricket in Australia',
        region: 'Australia',
        url: 'https://kayosports.com.au',
        icon: Icons.play_circle_outline,
      ),
      WatchSite(
        name: 'ICC.tv',
        description: 'Official ICC live and on-demand',
        region: 'Selected regions',
        url: 'https://www.icc.tv',
        icon: Icons.play_circle_outline,
      ),
      WatchSite(
        name: 'YouTube',
        description: 'Free official streams where available',
        region: 'Worldwide',
        url: 'https://www.youtube.com/results?search_query=cricket+live',
        icon: Icons.smart_display_outlined,
      ),
    ],
  ),
  WatchCategory(
    title: 'Live Scores & Commentary',
    subtitle: 'Ball-by-ball updates and stats',
    icon: Icons.leaderboard,
    sites: [
      WatchSite(
        name: 'Cricbuzz',
        description: 'Live scores, commentary and stats',
        region: 'Worldwide',
        url: 'https://www.cricbuzz.com',
        icon: Icons.sports_cricket,
      ),
      WatchSite(
        name: 'ESPNcricinfo',
        description: 'Scores, news and analysis',
        region: 'Worldwide',
        url: 'https://www.espncricinfo.com',
        icon: Icons.sports_cricket,
      ),
      WatchSite(
        name: 'ICC Cricket',
        description: 'Rankings, fixtures and results',
        region: 'Worldwide',
        url: 'https://www.icc-cricket.com',
        icon: Icons.sports_cricket,
      ),
    ],
  ),
  WatchCategory(
    title: 'Boards & Highlights',
    subtitle: 'Official sites for news and highlights',
    icon: Icons.emoji_events_outlined,
    sites: [
      WatchSite(
        name: 'ICC on YouTube',
        description: 'Official highlights and interviews',
        region: 'Worldwide',
        url: 'https://www.youtube.com/@icc',
        icon: Icons.smart_display_outlined,
      ),
      WatchSite(
        name: 'Sri Lanka Cricket',
        description: 'Fixtures and news',
        region: 'Sri Lanka',
        url: 'https://www.srilankacricket.lk',
        icon: Icons.public,
      ),
      WatchSite(
        name: 'BCCI',
        description: 'Fixtures and news',
        region: 'India',
        url: 'https://www.bcci.tv',
        icon: Icons.public,
      ),
    ],
  ),
];
