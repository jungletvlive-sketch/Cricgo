import '../models/cricket_match.dart';

// Demo data, shown only when the app is built without an API key.
List<CricketMatch> sampleMatches() {
  final now = DateTime.now();

  return [
    CricketMatch(
      id: 'demo-1',
      title: '2nd T20I',
      format: 'T20',
      teamA: const TeamInfo(name: 'Sri Lanka', shortName: 'SL'),
      teamB: const TeamInfo(name: 'India', shortName: 'IND'),
      scoreA: '142/4 (15.2)',
      scoreB: '',
      startTime: now.subtract(const Duration(hours: 1)),
      venue: 'R. Premadasa Stadium, Colombo',
      status: MatchStatus.live,
      statusText: 'Sri Lanka batting',
    ),
    CricketMatch(
      id: 'demo-2',
      title: '1st ODI',
      format: 'ODI',
      teamA: const TeamInfo(name: 'Australia', shortName: 'AUS'),
      teamB: const TeamInfo(name: 'England', shortName: 'ENG'),
      startTime: now.add(const Duration(hours: 5)),
      venue: 'Melbourne Cricket Ground',
      status: MatchStatus.upcoming,
      statusText: 'Match not started',
    ),
    CricketMatch(
      id: 'demo-3',
      title: '1st Test',
      format: 'TEST',
      teamA: const TeamInfo(name: 'South Africa', shortName: 'SA'),
      teamB: const TeamInfo(name: 'Pakistan', shortName: 'PAK'),
      startTime: now.add(const Duration(days: 1, hours: 2)),
      venue: 'Newlands, Cape Town',
      status: MatchStatus.upcoming,
      statusText: 'Match not started',
    ),
    CricketMatch(
      id: 'demo-4',
      title: '3rd T20I',
      format: 'T20',
      teamA: const TeamInfo(name: 'New Zealand', shortName: 'NZ'),
      teamB: const TeamInfo(name: 'Bangladesh', shortName: 'BAN'),
      scoreA: '176/6 (20)',
      scoreB: '170/8 (20)',
      startTime: now.subtract(const Duration(days: 1)),
      venue: 'Eden Park, Auckland',
      status: MatchStatus.completed,
      statusText: 'New Zealand won by 6 runs',
    ),
  ];
}
