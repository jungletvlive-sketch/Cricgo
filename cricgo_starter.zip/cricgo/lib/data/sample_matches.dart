import '../models/cricket_match.dart';

// Sample data only. Later this will come from Firestore (broadcast info)
// and a cricket API (fixtures + live status).
List<CricketMatch> sampleMatches() {
  final now = DateTime.now();

  const sonyLiv = Broadcaster(
    name: 'Sony LIV',
    country: 'India',
    url: 'https://www.sonyliv.com',
  );
  const willow = Broadcaster(
    name: 'Willow',
    country: 'USA / Canada',
    url: 'https://www.willow.tv',
  );
  const youtube = Broadcaster(
    name: 'YouTube',
    country: 'Worldwide',
    url: 'https://www.youtube.com',
  );

  return [
    CricketMatch(
      id: '1',
      series: 'Sample T20 Series',
      format: 'T20',
      teamA: 'Team A',
      teamB: 'Team B',
      startTime: now.subtract(const Duration(hours: 1)),
      venue: 'Sample Stadium, Colombo',
      status: MatchStatus.live,
      scoreSummary: 'Team A 142/4 (15.2 ov)',
      broadcasters: const [sonyLiv, willow, youtube],
    ),
    CricketMatch(
      id: '2',
      series: 'Sample ODI Series',
      format: 'ODI',
      teamA: 'Team C',
      teamB: 'Team D',
      startTime: now.add(const Duration(hours: 5)),
      venue: 'Sample Ground, Mumbai',
      status: MatchStatus.upcoming,
      broadcasters: const [sonyLiv, willow],
    ),
    CricketMatch(
      id: '3',
      series: 'Sample Test Series',
      format: 'Test',
      teamA: 'Team E',
      teamB: 'Team F',
      startTime: now.add(const Duration(days: 1, hours: 2)),
      venue: 'Sample Oval, Melbourne',
      status: MatchStatus.upcoming,
      broadcasters: const [youtube],
    ),
  ];
}
