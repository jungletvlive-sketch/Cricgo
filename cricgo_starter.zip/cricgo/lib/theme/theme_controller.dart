import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

class ThemeController extends ChangeNotifier {
  static const String _key = 'theme_mode';

  ThemeMode mode = ThemeMode.dark;

  Future<void> load() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final saved = prefs.getString(_key);
      if (saved == 'light') {
        mode = ThemeMode.light;
      } else if (saved == 'system') {
        mode = ThemeMode.system;
      } else {
        mode = ThemeMode.dark;
      }
      notifyListeners();
    } catch (_) {
      // Keep the default if storage is unavailable.
    }
  }

  Future<void> set(ThemeMode newMode) async {
    mode = newMode;
    notifyListeners();
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setString(_key, newMode.name);
    } catch (_) {}
  }

  void toggle(Brightness current) {
    set(current == Brightness.dark ? ThemeMode.light : ThemeMode.dark);
  }
}
