import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class AppColors {
  static const Color primary = Color(0xFF0B3D91);
  static const Color accent = Color(0xFFFF5A1F);
  static const Color live = Color(0xFFE53935);
  static const Color lightBg = Color(0xFFF3F6FB);
  static const Color darkBg = Color(0xFF0E1621);
  static const Color darkCard = Color(0xFF16222F);
  static const Color lightCard = Colors.white;

  static bool isDark(BuildContext c) =>
      Theme.of(c).brightness == Brightness.dark;

  static Color card(BuildContext c) => isDark(c) ? darkCard : lightCard;

  static Color border(BuildContext c) =>
      isDark(c) ? const Color(0x1FFFFFFF) : const Color(0x14000000);

  static Color muted(BuildContext c) =>
      Theme.of(c).colorScheme.onSurface.withValues(alpha: 0.62);

  static Color placeholder(BuildContext c) =>
      Theme.of(c).colorScheme.onSurface.withValues(alpha: 0.09);
}

class AppTheme {
  static ThemeData light() => _build(Brightness.light);
  static ThemeData dark() => _build(Brightness.dark);

  static ThemeData _build(Brightness b) {
    final dark = b == Brightness.dark;
    final bg = dark ? AppColors.darkBg : AppColors.lightBg;

    final scheme = ColorScheme.fromSeed(
      seedColor: AppColors.primary,
      brightness: b,
    ).copyWith(
      primary: dark ? const Color(0xFF7FAAFF) : AppColors.primary,
      secondary: AppColors.accent,
      surface: bg,
    );

    final base = ThemeData(
      useMaterial3: true,
      brightness: b,
      colorScheme: scheme,
      scaffoldBackgroundColor: bg,
    );

    return base.copyWith(
      textTheme: GoogleFonts.poppinsTextTheme(base.textTheme),
      appBarTheme: AppBarTheme(
        backgroundColor: bg,
        foregroundColor: scheme.onSurface,
        elevation: 0,
        scrolledUnderElevation: 0,
        centerTitle: false,
      ),
      navigationBarTheme: NavigationBarThemeData(
        backgroundColor: dark ? AppColors.darkCard : AppColors.lightCard,
        indicatorColor: AppColors.accent.withValues(alpha: 0.22),
        elevation: 0,
      ),
    );
  }
}
