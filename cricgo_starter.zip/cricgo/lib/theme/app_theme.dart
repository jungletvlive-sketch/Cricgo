import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class AppColors {
  static const primary = Color(0xFF0B3D91);
  static const accent = Color(0xFFFF5A1F);
  static const live = Color(0xFFE53935);
  static const lightBg = Color(0xFFF5F7FA);
  static const darkBg = Color(0xFF0E1621);
  static const darkCard = Color(0xFF16222F);
}

class AppTheme {
  static ThemeData light() {
    final base = ThemeData(
      brightness: Brightness.light,
      colorScheme: ColorScheme.fromSeed(
        seedColor: AppColors.primary,
        secondary: AppColors.accent,
        brightness: Brightness.light,
      ),
      scaffoldBackgroundColor: AppColors.lightBg,
      useMaterial3: true,
    );
    return base.copyWith(textTheme: GoogleFonts.poppinsTextTheme(base.textTheme));
  }

  static ThemeData dark() {
    final base = ThemeData(
      brightness: Brightness.dark,
      colorScheme: ColorScheme.fromSeed(
        seedColor: AppColors.primary,
        secondary: AppColors.accent,
        brightness: Brightness.dark,
      ),
      scaffoldBackgroundColor: AppColors.darkBg,
      cardColor: AppColors.darkCard,
      useMaterial3: true,
    );
    return base.copyWith(textTheme: GoogleFonts.poppinsTextTheme(base.textTheme));
  }
}
