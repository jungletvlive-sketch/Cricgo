import 'dart:math' as math;

import 'package:flutter/material.dart';

import '../theme/app_theme.dart';

/// CricGo logo: a cricket ball with a play triangle (watch live).
class CricGoLogo extends StatelessWidget {
  final double size;
  final bool glow;

  const CricGoLogo({super.key, this.size = 96, this.glow = false});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: size,
      height: size,
      decoration: glow
          ? BoxDecoration(
              shape: BoxShape.circle,
              boxShadow: [
                BoxShadow(
                  color: AppColors.accent.withValues(alpha: 0.45),
                  blurRadius: size * 0.4,
                  spreadRadius: size * 0.02,
                ),
              ],
            )
          : null,
      child: CustomPaint(painter: _LogoPainter()),
    );
  }
}

class _LogoPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final c = size.center(Offset.zero);
    final r = size.width / 2;

    final ballPaint = Paint()
      ..shader = const RadialGradient(
        center: Alignment(-0.3, -0.4),
        radius: 1.1,
        colors: [Color(0xFFFF8A50), Color(0xFFFF5A1F), Color(0xFFD93A00)],
        stops: [0.0, 0.55, 1.0],
      ).createShader(Rect.fromCircle(center: c, radius: r));
    canvas.drawCircle(c, r, ballPaint);

    final seam = Paint()
      ..color = Colors.white.withValues(alpha: 0.9)
      ..style = PaintingStyle.stroke
      ..strokeWidth = r * 0.05
      ..strokeCap = StrokeCap.round;

    final leftSeam = Path()
      ..addArc(
        Rect.fromCircle(center: Offset(c.dx - r * 1.45, c.dy), radius: r * 0.95),
        -0.6,
        1.2,
      );
    final rightSeam = Path()
      ..addArc(
        Rect.fromCircle(center: Offset(c.dx + r * 1.45, c.dy), radius: r * 0.95),
        math.pi - 0.6,
        1.2,
      );
    canvas.drawPath(leftSeam, seam);
    canvas.drawPath(rightSeam, seam);

    final s = r * 0.5;
    final play = Path()
      ..moveTo(c.dx - s * 0.5, c.dy - s * 0.7)
      ..lineTo(c.dx - s * 0.5, c.dy + s * 0.7)
      ..lineTo(c.dx + s * 0.8, c.dy)
      ..close();
    canvas.drawPath(play, Paint()..color = Colors.white);
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}
