import 'package:flutter/material.dart';

import '../models/cricket_match.dart';

class TeamBadge extends StatelessWidget {
  final TeamInfo team;
  final double size;

  const TeamBadge({super.key, required this.team, this.size = 38});

  @override
  Widget build(BuildContext context) {
    final url = team.imageUrl;
    return ClipOval(
      child: SizedBox(
        width: size,
        height: size,
        child: url == null
            ? _initials()
            : Image.network(
                url,
                fit: BoxFit.cover,
                errorBuilder: (context, error, stack) => _initials(),
                loadingBuilder: (context, child, progress) =>
                    progress == null ? child : _initials(),
              ),
      ),
    );
  }

  Widget _initials() {
    const palette = <Color>[
      Color(0xFF1E5BD8),
      Color(0xFF0E8F6B),
      Color(0xFF8E44AD),
      Color(0xFFD35400),
      Color(0xFFC0392B),
      Color(0xFF16808D),
    ];
    final color = palette[team.name.hashCode.abs() % palette.length];
    final text = team.shortName.length > 3
        ? team.shortName.substring(0, 3)
        : team.shortName;
    return Container(
      color: color,
      alignment: Alignment.center,
      child: Text(
        text,
        style: TextStyle(
          color: Colors.white,
          fontWeight: FontWeight.w700,
          fontSize: size * 0.3,
        ),
      ),
    );
  }
}
