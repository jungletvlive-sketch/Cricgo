import 'package:flutter/material.dart';

import '../models/cricket_match.dart';
import '../theme/app_theme.dart';
import '../utils/helpers.dart';
import 'team_badge.dart';

class MatchCard extends StatelessWidget {
  final CricketMatch match;
  final VoidCallback onTap;

  const MatchCard({super.key, required this.match, required this.onTap});

  @override
  Widget build(BuildContext context) {
    final isLive = match.status == MatchStatus.live;
    final muted = AppColors.muted(context);

    return Container(
      margin: const EdgeInsets.fromLTRB(16, 6, 16, 6),
      decoration: BoxDecoration(
        color: AppColors.card(context),
        borderRadius: BorderRadius.circular(18),
        border: Border.all(
          color: isLive
              ? AppColors.live.withValues(alpha: 0.5)
              : AppColors.border(context),
        ),
      ),
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          borderRadius: BorderRadius.circular(18),
          onTap: onTap,
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    if (match.format.isNotEmpty) ...[
                      _FormatChip(match.format),
                      const SizedBox(width: 8),
                    ],
                    Expanded(
                      child: Text(
                        match.title,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: TextStyle(color: muted, fontSize: 12),
                      ),
                    ),
                    _StatusPill(match.status),
                  ],
                ),
                const SizedBox(height: 14),
                _TeamRow(team: match.teamA, score: match.scoreA),
                const SizedBox(height: 10),
                _TeamRow(team: match.teamB, score: match.scoreB),
                const SizedBox(height: 14),
                Divider(height: 1, color: AppColors.border(context)),
                const SizedBox(height: 12),
                if (match.statusText.isNotEmpty)
                  Text(
                    match.statusText,
                    style: TextStyle(
                      color: isLive ? AppColors.accent : muted,
                      fontWeight: FontWeight.w600,
                      fontSize: 13,
                    ),
                  ),
                if (match.statusText.isNotEmpty) const SizedBox(height: 8),
                Row(
                  children: [
                    Icon(Icons.schedule, size: 15, color: muted),
                    const SizedBox(width: 6),
                    Text(formatMatchTime(match.startTime),
                        style: TextStyle(color: muted, fontSize: 12)),
                  ],
                ),
                if (match.venue.isNotEmpty) ...[
                  const SizedBox(height: 4),
                  Row(
                    children: [
                      Icon(Icons.location_on_outlined, size: 15, color: muted),
                      const SizedBox(width: 6),
                      Expanded(
                        child: Text(
                          match.venue,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: TextStyle(color: muted, fontSize: 12),
                        ),
                      ),
                    ],
                  ),
                ],
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class _TeamRow extends StatelessWidget {
  final TeamInfo team;
  final String score;

  const _TeamRow({required this.team, required this.score});

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        TeamBadge(team: team),
        const SizedBox(width: 12),
        Expanded(
          child: Text(
            team.name,
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w600),
          ),
        ),
        if (score.isNotEmpty)
          Text(
            score,
            style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w700),
          ),
      ],
    );
  }
}

class _FormatChip extends StatelessWidget {
  final String text;
  const _FormatChip(this.text);

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
      decoration: BoxDecoration(
        color: AppColors.accent.withValues(alpha: 0.16),
        borderRadius: BorderRadius.circular(8),
      ),
      child: Text(
        text,
        style: const TextStyle(
          color: AppColors.accent,
          fontSize: 11,
          fontWeight: FontWeight.w700,
        ),
      ),
    );
  }
}

class _StatusPill extends StatelessWidget {
  final MatchStatus status;
  const _StatusPill(this.status);

  @override
  Widget build(BuildContext context) {
    late final String label;
    late final Color color;
    switch (status) {
      case MatchStatus.live:
        label = 'LIVE';
        color = AppColors.live;
      case MatchStatus.upcoming:
        label = 'UPCOMING';
        color = const Color(0xFF2F7DE1);
      case MatchStatus.completed:
        label = 'RESULT';
        color = const Color(0xFF7A8794);
    }
    final live = status == MatchStatus.live;
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
      decoration: BoxDecoration(
        color: live ? color : color.withValues(alpha: 0.16),
        borderRadius: BorderRadius.circular(20),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          if (live) ...[
            Container(
              width: 6,
              height: 6,
              decoration: const BoxDecoration(
                color: Colors.white,
                shape: BoxShape.circle,
              ),
            ),
            const SizedBox(width: 5),
          ],
          Text(
            label,
            style: TextStyle(
              color: live ? Colors.white : color,
              fontSize: 10.5,
              fontWeight: FontWeight.w800,
              letterSpacing: 0.8,
            ),
          ),
        ],
      ),
    );
  }
}
